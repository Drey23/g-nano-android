/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.google.ai.client.generativeai.common;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.google.ai.client.generativeai.common";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_NAME = "0.8.0";
}
